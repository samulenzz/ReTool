import json

words = {
    ''
}

def _classify():
    ...