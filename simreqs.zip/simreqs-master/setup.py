from setuptools import setup, find_namespace_packages


setup(
    name="simreqs",
    version="0.0.1",
    packages=find_namespace_packages(),
    package_data={'simireqs': ['data/*']},
    install_requires=[
        'fire',
        'numpy',
        'scipy',
        'gensim',
        'opencc-python-reimplemented',
        'jieba'
    ]
)
