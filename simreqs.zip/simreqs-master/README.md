# simreqs

## Installation

```shell
cd simreqs
pip3 install .
```

## CLI Usage

详细使用方法请参考源代码或

```
python3 -m simreqs --help
```

### 训练Word2Vec模型

可以通过[百度网盘](https://pan.baidu.com/s/1wZa3u2tWGlfS15tpDYu93A)（提取码56au）直接下载，或者通过以下步骤进行训练。获得模型之后需要修改`similarity.py`中的模型路径。

#### 1. 准备语料

本项目从[nlp_chinese_corpus](https://github.com/brightmart/nlp_chinese_corpus)获取语料。共用到：

+ 维基百科
+ 新闻语料
+ 百科问答

下载后解压到相应的文件夹中。

#### 2. 预处理

**维基百科**

```
python3 -m simreqs process-corpus wikizh CORPUS_DIR ODIR
```

**新闻语料**

```
python3 -m simreqs process-corpus newszh CORPUS_JSON_FILE ODIR
```

**百科问答**

```
python3 -m simreqs process-corpus baikeqazh CORPUS_JSON_FILE ODIR
```

#### 3. 训练

```
python3 -m simreqs train CORPUS_DIR ODIR [SIZE] [WINDOW_SIZE] [WORKERS]
```

### 计算句子相似度

```
python3 -m simreqs sentence-similarity SENTENCE1 SENTENCE2
```

### 运行DEMO

```
python3 -m simreqs run-demo
```

### Benchmarks

```
python3 -m simreqs benchmarks DATA_DIR
```

